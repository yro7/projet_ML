"""Composable ensemble classifiers"""
